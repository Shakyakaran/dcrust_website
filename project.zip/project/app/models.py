from django.db import models

class NoticeBoard(models.Model):

    title = models.CharField(max_length=255)
    description = models.CharField(max_length=600)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.title
    
class TimeTable(models.Model):

    sem = models.CharField(max_length=50)
    pdf = models.FileField(upload_to='pdfs/Timetable/')

    def __str__(self):
        return self.sem

    