from django.urls import path
from . import views

urlpatterns = [

    path('', views.home),
    path('delete_notice/<id>', views.delete_notice, name='delete_notice'),
    path('delete_time_table/<id>', views.delete_time_table, name='delete_time_table'),
    path('update_time_table/<id>', views.update_time_table, name='update_time_table'),
    path('add_notice/', views.add_notice, name='add_notice'),
    path('edit_time_table/', views.edit_time_table, name='edit_time_table'),
    path('upload_attendance/', views.upload_attendance, name='upload_attendance'),


]
