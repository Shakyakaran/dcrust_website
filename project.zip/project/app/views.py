from django.shortcuts import render, HttpResponse, redirect
from .models import NoticeBoard, TimeTable

# Create your views here.
def home(request):

    notices = NoticeBoard.objects.all().order_by('-uploaded_at')

    return render(request, 'home.html', {'notices':notices})

def delete_notice(request, id):

    notice = NoticeBoard.objects.get(id=id)

    if request.user.is_superuser:
        notice.delete()

    return redirect('/#menu')

def add_notice(request):

    if request.user.is_superuser:

        if request.method=="POST":

            title = request.POST.get("title")
            description = request.POST.get("description")

            NoticeBoard.objects.create(title=title, description=description)

            return redirect('/#menu')

    return render(request, 'Add_notice.html')

def edit_time_table(request):

    time_table_list = TimeTable.objects.all()

    if request.user.is_superuser:

        if request.method=="POST":

            sem = request.POST.get('semester')
            pdf = request.FILES.get('pdf')


            # print(pdf)

            if sem and pdf:
                TimeTable.objects.create(sem=sem, pdf=pdf)
                return redirect('/edit_time_table')

    context = {
        'pdfs': time_table_list,
    }

    return render(request, 'edit_time_table.html',context)

def delete_time_table(request, id):

    if request.user.is_superuser:

        edit = TimeTable.objects.get(id=id)

        edit.delete()

    return redirect('/edit_time_table')

def update_time_table(request, id):

    time_table = TimeTable.objects.get(id=id)

    if request.method == "POST":



        sem = request.POST.get('semester')
        pdf = request.FILES.get('pdf')

        print(sem, pdf)

        if pdf and sem:

            time_table.sem = sem
            time_table.pdf = pdf

            time_table.save()

        return redirect('/edit_time_table')

    
    context = {
        'update_pdf' : time_table
    }

    return render(request, 'edit_time_table.html', context)

def upload_attendance(request):

    context={
        'students': ['Aayush','Harsh','Karan','Palak','Sakshi']
    }

    return render(request, 'upload_attendance.html', context)