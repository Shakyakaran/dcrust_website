from django.shortcuts import render,redirect,HttpResponse
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode,urlsafe_base64_decode
# from .utils import TokenGenerator, generate_token
from django.utils.encoding import force_bytes,force_str
from django.core.mail import EmailMessage
from django.conf import settings
from django.views.generic import View
from django.contrib.auth import authenticate,login,logout

def signup(request):

    if (request.method == "POST"):
        email = request.POST['email']
        password = request.POST['pass1']
        confirm_password = request.POST['pass2']
        
        if password != confirm_password:
            messages.warning(request, 'Password is not matching !')
            return render(request, 'auth_user/signup.html')
        
        try:
            if User.objects.get(username = email):
                return HttpResponse('email already exists')
        
        except:
            pass

        user = User.objects.create_user(email, email, password)
        user.is_active=True
        user.save()

        return HttpResponse('User created', email)

    return render(request ,'signup.html')

def handlelogin(request):

    if request.method=="POST":
        username = request.POST['email']
        userpassword = request.POST['pass1']
        myuser = authenticate(username=username, password=userpassword)

        if myuser is not None:
            login(request, myuser)
            # messages.success(request,'Login success')
            return redirect('/')
        else:
            print(username,' ',userpassword)
            # messages.error(request,'Invalid credentials')
            return redirect('/auth/login')
        
    return render(request, 'login.html')

def handlelogout(request):

    logout(request)
    messages.info(request, 'Logout success')

    return redirect('/auth/login')





