from django.contrib import admin

from .models import *

admin.site.register(pyqPdf)
admin.site.register(sylPdf)