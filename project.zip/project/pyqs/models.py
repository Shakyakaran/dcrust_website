from django.db import models

class pyqPdf(models.Model):
    title = models.CharField(max_length=255)
    pdf = models.FileField(upload_to='pdfs/pyqs/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    year = models.CharField(max_length=5)
    courseCode = models.CharField(max_length=10)
    sem = models.CharField(max_length=5)


    def __str__(self):
        return self.title
    
class sylPdf(models.Model):

    title = models.CharField(max_length=255)
    pdf = models.FileField(upload_to='pdfs/syllabus/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    courseCode = models.CharField(max_length=10)
    sem = models.CharField(max_length=5)
    branch = models.CharField(max_length=255)


    def __str__(self):
        return self.title