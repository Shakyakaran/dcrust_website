from django.urls import path
from . import views

urlpatterns = [

    path('home/', views.homee),
    path('upload/', views.upload_pdf, name='upload_pdf'),
    path('', views.pdf_list, name='pdf_list'),
    path('upload_syl/', views.upload_sylpdf, name='upload_sylpdf'),
    path('syl_list/', views.sylpdf_list, name='sylpdf_list'),
    path('pyqs/', views.PYQs, name='pyqs'),
    path('time_table/', views.time_table_list, name='pyqs'),

]
