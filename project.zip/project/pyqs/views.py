from django.shortcuts import render, redirect
from app.models import TimeTable
from .models import *

# Create your views here.
def homee(request):
    return render(request, 'homee.html')



def upload_pdf(request):

    if request.user.is_superuser:
        if request.method == 'POST':
            title = request.POST.get('title')
            year = request.POST.get('year')
            courseCode = request.POST.get('courseCode')
            sem = request.POST.get('sem')
            pdf = request.FILES.get('pdf')
            

            if title and pdf:
                pyqPdf.objects.create(title=title, pdf=pdf,year=year,courseCode=courseCode,sem=sem)
                return redirect('pdf_list')
        
    return render(request, 'upload_pdf.html')

def pdf_list(request):

    if request.method=='POST':

        course_code = request.POST.get('course_code')
        course_pdf = pyqPdf.objects.all().filter(courseCode=course_code)

        return render(request, 'pdf_list.html', {'pdfs': course_pdf})




    pdfs = pyqPdf.objects.all()
    return render(request, 'pdf_list.html', {'pdfs': pdfs})

def upload_sylpdf(request):

    if request.user.is_superuser:

        if request.method == 'POST':
            title = request.POST.get('title')
            courseCode = request.POST.get('courseCode')
            sem = request.POST.get('sem')
            pdf = request.FILES.get('pdf')
            branch = request.POST.get('branch')
            

            if title and pdf:
                sylPdf.objects.create(title=title, pdf=pdf,courseCode=courseCode,sem=sem,branch=branch)
                return redirect('sylpdf_list')
        
    return render(request, 'syl_upload.html')


def PYQs(request):
    pdfs = pyqPdf.objects.all()
    return render(request, 'pyqs.html',{'pdfs': pdfs})


def sylpdf_list(request):
    pdfs = sylPdf.objects.all().order_by('sem')
    return render(request, 'sylpdf_list.html', {'pdfs': pdfs})


def time_table_list(request):
    pdfs = TimeTable.objects.all()
    return render(request, 'view_time_table.html', {'pdfs': pdfs})

